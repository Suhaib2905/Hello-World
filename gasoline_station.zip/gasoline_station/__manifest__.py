{
    'name': 'Saudikom Gasoline Station',
    'summary': """
        Saudikom gasoline station module
    """,
    'description': """
        Saudikom gasoline station module
    """,
    'version': '1.0',
    'author': 'shar',
    'depends': [
        'base',
        'hr',
    ],
    'data': [
        'views/gasoline.xml',
    ],
}